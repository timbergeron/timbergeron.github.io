#define SDL_REVISION "https://github.com/libsdl-org/SDL.git@981e1e3c4489add5bf6d4df5415af3cf1ef2773d"
#define SDL_REVISION_NUMBER 0
